/*
 * Minimal stdlib.h for embedded systems
 * Provides basic type definitions but no actual implementations
 */

#ifndef _STDLIB_H
#define _STDLIB_H

#include <stddef.h>

/* NULL is already defined in stddef.h */

/* Exit status codes */
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1

/* Maximum random value (not implemented) */
#define RAND_MAX 32767

/* Function prototypes - not implemented for embedded, just declarations */
/* These can be stubbed if needed by user code */

#endif /* _STDLIB_H */
