/**
 * Minimal freestanding stddef.h for ARM Cortex-M
 * Provides common type definitions
 */

#ifndef _STDDEF_H
#define _STDDEF_H

/* NULL pointer constant */
#ifndef NULL
#ifdef __cplusplus
#define NULL 0
#else
#define NULL ((void *)0)
#endif
#endif

/* size_t - unsigned integer type for sizeof */
typedef unsigned int size_t;

/* ptrdiff_t - signed integer type for pointer subtraction */
typedef int ptrdiff_t;

/* wchar_t - wide character type (not typically used in embedded) */
#ifndef __cplusplus
typedef int wchar_t;
#endif

/* max_align_t - type with maximum alignment requirement */
typedef long double max_align_t;

/* offsetof macro */
#define offsetof(type, member) __builtin_offsetof(type, member)

#endif /* _STDDEF_H */
